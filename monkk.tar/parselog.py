#proj  :91log
#module:parse_tarfile
#date  :Thu Oct 17 17:49:57 2013
#author:kk

def getlogbyclass(classid):
    pass

def getlogbyclient(userid):
    pass

def getlogbyserver(ip):
    pass

